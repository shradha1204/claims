package com.claims.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name="Claim")

@Table(name = "Claims")
public class Claim {
	@Id
	private Integer claimId;
	private String memberId;
	private String claimServiceDate;
	private String claimSubmissionDate;
	private String claimProcessingDate;
	private String claimStatus="New";
	private Integer claimAmount;
	private Integer approvedAmount;
	
	public Integer getClaimId() {
		return claimId;
	}

	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getClaimServiceDate() {
		return claimServiceDate;
	}

	public void setClaimServiceDate(String claimServiceDate) {
		this.claimServiceDate = claimServiceDate;
	}

	public String getClaimSubmissionDate() {
		return claimSubmissionDate;
	}

	public void setClaimSubmissionDate(String claimSubmissionDate) {
		this.claimSubmissionDate = claimSubmissionDate;
	}

	public String getClaimProcessingDate() {
		return claimProcessingDate;
	}

	public void setClaimProcessingDate(String claimProcessingDate) {
		this.claimProcessingDate = claimProcessingDate;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

	public Integer getClaimAmount() {
		return claimAmount;
	}

	public void setClaimAmount(Integer claimAmount) {
		this.claimAmount = claimAmount;
	}

	public Integer getApprovedAmount() {
		return approvedAmount;
	}

	public void setApprovedAmount(Integer approvedAmount) {
		this.approvedAmount = approvedAmount;
	}
	
	public String toString() {
        return "Claim [memberId=" + memberId + ", claimServiceDate=" + claimServiceDate
                + ", claimSubmissionDate=" + claimSubmissionDate + ",claimProcessingDate=" + claimProcessingDate + ",claimStatus=" + claimStatus + ", claimAmount=" + claimAmount + ", approvedAmount=" + approvedAmount + "]";
    }
}
