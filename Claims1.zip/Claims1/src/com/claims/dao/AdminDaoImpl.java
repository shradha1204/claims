package com.claims.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.claims.entity.Admin;
import com.claims.entity.Claim;
import com.claims.entity.Member;

@Repository
public class AdminDaoImpl implements AdminDao {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@Transactional
	public void addAdmin(Admin a) {
		// TODO Auto-generated method stub
		System.out.println("here");
		sessionFactory.getCurrentSession().save(a);
		System.out.println("here 2");
	}

	@Override
	@Transactional
	public void addMember(Member m) {
		// TODO Auto-generated method stub
		System.out.println("here");
		sessionFactory.getCurrentSession().save(m);
		System.out.println("here 2");
	}

	@Override
	@Transactional
	public List<Admin> listAdmin() {
		// TODO Auto-generated method stub

		return sessionFactory.getCurrentSession().createQuery("From Admin").list();
	}

	@Override
	@Transactional
	public List<Member> listMember() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("From Member").list();
	}

	@Override
	@Transactional
	public Admin fetchAdminByAdminId(String id) {
		// TODO Auto-generated method stub
		System.out.println("inside fetch id " + id);
		Session s = this.sessionFactory.getCurrentSession();
		Query q = s.createQuery("from Admin l where l.adminId=:id");
		q.setParameter("id", id);
		Admin l1 = (Admin) q.uniqueResult();
		if (l1 != null) {
			System.out.println("inside fetch return " + id);
			return l1;
		}
		return null;
	}

	@Override
	@Transactional
	public Member fetchMemberByMemberId(String id) {
		// TODO Auto-generated method stub
		Session s = this.sessionFactory.getCurrentSession();
		Query q = s.createQuery("from Member l where l.memberId=:id and l.status = 'Accepted'");
		q.setParameter("id", id);
		Member l1 = (Member) q.uniqueResult();
		if (l1 != null) {
			return l1;
		}
		return null;
	}

	@Override
	@Transactional
	public boolean checkPassword(Admin user) {
		// TODO Auto-generated method stub
		Session s = this.sessionFactory.getCurrentSession();
		Query q = s.createQuery("from Admin l where l.id=:id and l.password=:pass");
		q.setParameter("id", user.getAdminId());
		q.setParameter("pass", user.getPassword());
		Admin l1 = (Admin) q.uniqueResult();
		System.out.println("ok" + l1);
		if (l1 != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public boolean checkPassword1(Member user) {
		// TODO Auto-generated method stub
		Session s = this.sessionFactory.getCurrentSession();
		Query q = s.createQuery("from Member l where l.id=:id and l.password=:pass ");
		q.setParameter("id", user.getMemberId());
		q.setParameter("pass", user.getPassword());
		Member l1 = (Member) q.uniqueResult();
		System.out.println("ok" + l1);
		if (l1 != null)
			return true;
		else
			return false;
	}

	@Override
	@Transactional
	public Admin findById(String emailId) {
		System.out.println("inside findbyid**********************************************");
		try {
			System.out.println("printing user :: ------------------" + emailId);
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Admin.class);
			System.out.println("updated....2");
			List<Admin> users = criteria.add(Restrictions.like("emailId", emailId.trim())).list();
			Admin user = users.get(0);
			System.out.println(user);
			return user;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public void updatePassword(Admin dbUser) {
		System.out.println("In dao : " + dbUser.getEmailId() + " -------" + dbUser.getPassword());
		Session session = null;
		Query q = null;
		try {
			session = sessionFactory.getCurrentSession();
			q = session.createQuery("UPDATE Admin u set u.password=:pass where emailId=:mail");
			q.setParameter("pass", dbUser.getPassword());
			q.setParameter("mail", dbUser.getEmailId());
			int i = q.executeUpdate();
			System.out.println(i + "  rows affected");
		} catch (Exception e) {
			System.out.println(e);
		} 
	}

	@Override
	@Transactional
	public Member findById1(String emailId) {
		System.out.println("inside findbyid**********************************************");
		try {
			System.out.println("printing user :: ------------------" + emailId);
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Member.class);
			System.out.println("updated....2");
			List<Member> users = criteria.add(Restrictions.like("emailId", emailId.trim())).list();
			for (Member m : users)
				System.out.println(m.getEmailId() + "--------------------------------");
			return users.get(0);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	@Override
	@Transactional
	public void updatePassword1(Member dbUser) {
		System.out.println("In Dao");
		System.out.println("In dao : " + dbUser.getEmailId() + " -------" + dbUser.getPassword());
		Session session = null;
		Query q = null;
		try {
			session = sessionFactory.getCurrentSession();
			q = session.createQuery("UPDATE Member u set u.password=:pass1 where emailId=:mail1");
			q.setParameter("pass1", dbUser.getPassword());
			q.setParameter("mail1", dbUser.getEmailId());
			int i = q.executeUpdate();
			System.out.println(i + "  rows affected");
		} catch (Exception e) {
			System.out.println(e);
		}
	}	
	@Override
	@Transactional
	public void addClaim2(Claim c) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(c);
	}

	@Override
	@Transactional
	public void updateClaim2(Claim c) {
		// TODO Auto-generated method stub
		 sessionFactory.getCurrentSession().update(c);

	}

	@Override
	@Transactional
	public Claim getClaimById2(Integer Claimid) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Claim c=(Claim)s.get(Claim.class,Claimid);
		return c;
	}

	@Override
	@Transactional
	public List<Claim> listClaim2() {
		// TODO Auto-generated method stub
		return sessionFactory.getCurrentSession().createQuery("From Claim").list();
	}
	@Override
	@Transactional
	public List<Claim> listClaim2(String c) 
	{
		Criteria criteria =  sessionFactory.getCurrentSession().createCriteria(Claim.class);
		criteria.add(Restrictions.eq("memberId",c));
		List<Claim> claims = (List<Claim>) criteria.list();
		System.err.println("Members count: " + claims.size() + "   C = " + c);
		return claims;
		
	}
	@Override
	@Transactional
	public List<String> fetchPlanCodes() {
		// TODO Auto-generated method stub
		Session s = sessionFactory.getCurrentSession();
		Query q = s.createQuery("select planCode from planCode");
		List<String> l = q.list();
		return l;
	}
}