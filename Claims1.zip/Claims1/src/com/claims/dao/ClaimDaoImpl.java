package com.claims.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.icu.text.DateFormat;
import com.claims.entity.Claim;
import com.claims.entity.planCode;
import com.claims.entity.Member;

public class ClaimDaoImpl implements ClaimDao {
	
	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	@Override
	public List<Claim> listClaim() {
		// TODO Auto-generated method stub

		Session s=sessionFactory.getCurrentSession();
		Query q=s.createQuery("From Claim c where c.claimStatus=:s");
		q.setParameter("s", "New");
		List<Claim> l=q.list();
		return l;
	}
	@Transactional
	@Override
	public List<Claim> listClaimP() {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Query q=s.createQuery("From Claim c where c.claimStatus=:s");
		q.setParameter("s", "Accepted");
		List<Claim> l=q.list();
		return l;
	}
	@Transactional
	@Override
	public List<Member> listMember1() {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Query q=s.createQuery("From Member c where c.status=:s");
		q.setParameter("s", "New");
		List<Member> l=q.list();
		return l;
	}
	
	@Transactional
	@Override
	public void updateClaim(Integer c) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		System.out.println(c);
		Query q=s.createQuery("update Claim c set c.claimStatus=:s where c.claimId=:memid");
		q.setParameter("s", "Accepted");
		q.setParameter("memid", c);
		q.executeUpdate();
	}
	@Transactional
	@Override
	public void updateClaim1(Integer c) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		System.out.println(c);
		Query q=s.createQuery("update Claim c set c.claimStatus=:s where c.claimId=:memid");
		q.setParameter("s", "Denied");
		q.setParameter("memid", c);
		q.executeUpdate();
	}
	@Transactional
	@Override
	public Claim getClaimById(Integer ClaimId) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		Claim c=(Claim)s.get(Claim.class,ClaimId);
		return c;
	}
	@Transactional
	@Override
	public List<Member> listMember(String c) 
	{
		Criteria criteria =  sessionFactory.getCurrentSession().createCriteria(Member.class);
		criteria.add(Restrictions.idEq(c));
		List<Member> members = (List<Member>) criteria.list();
		System.err.println("Members count: " + members.size() + "   C = " + c);
		return members;
		
	}
	@Transactional
	@Override
	public List<Claim> listClaim1(Integer c) 
	{
		
		
		Criteria criteria =  sessionFactory.getCurrentSession().createCriteria(Claim.class);
		criteria.add(Restrictions.idEq(c));
		List<Claim> claims = (List<Claim>) criteria.list();
		System.err.println("Members count: " + claims.size() + "   C = " + c);
		return claims;
		
	}
	@Transactional
	@Override
	public void updateClaim3(String c) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		System.out.println(c);
		Query q=s.createQuery("UPDATE Member c set c.status=:s where c.memberId=:memid");
		q.setParameter("s", "Accepted");
		q.setParameter("memid", c);
		q.executeUpdate();
	}
	@Transactional
	@Override
	public void updateClaim4(String c) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		System.out.println(c);
		Query q=s.createQuery("UPDATE Member c set c.status=:s where c.memberId=:memid");
		q.setParameter("s", "Denied");
		q.setParameter("memid", c);
		q.executeUpdate();
	}
	@Transactional
	@Override
	public boolean updateA(Claim claim) {
		// TODO Auto-generated method stub
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		Date date = new Date();
		String date1=dateFormat.format(date);
		System.out.println(dateFormat.format(date));
		Session s=sessionFactory.getCurrentSession();
		Query q=s.createQuery("update Claim c set c.approvedAmount=:s where c.claimId=:claimId");
		q.setParameter("s", claim.getApprovedAmount());
		q.setParameter("claimId", claim.getClaimId());
		Query q1=s.createQuery("update Claim c set c.claimSubmissionDate=:p where c.claimId=:claimId");
		q1.setParameter("p",date1);
		q1.setParameter("claimId", claim.getClaimId());
		q1.executeUpdate();
		int i=q.executeUpdate();
		q1.executeUpdate();
		if(i>0)
			return true;
		else
			return false;
	}
	@Transactional
	@Override
	public List<planCode> listplanCode() {
		// TODO Auto-generated method stub

		return sessionFactory.getCurrentSession().createQuery("From planCode").list();
	}
	@Transactional
	@Override
	public void addClaim(planCode c) {
		// TODO Auto-generated method stub
		sessionFactory.getCurrentSession().save(c);
	}
	@Transactional
	@Override
	public void updateClaim5(planCode c) {
		// TODO Auto-generated method stub
		 sessionFactory.getCurrentSession().update(c);
	}
	@Transactional
	@Override
	public planCode getClaimById1(String planCode) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession();
		 planCode c=(planCode)s.get(planCode.class,planCode); return c;
	}
	@Transactional
	@Override
	public void removeClaim(String planCode) {
		// TODO Auto-generated method stub
		Session s=sessionFactory.getCurrentSession(); 
		planCode c=(planCode)s.get(planCode.class,planCode); 
		if(c!=null) s.delete(c);
	}

}
