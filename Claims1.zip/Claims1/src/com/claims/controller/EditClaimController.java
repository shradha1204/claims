package com.claims.controller;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.claims.entity.Claim;
import com.claims.entity.planCode;
import com.claims.entity.Member;
import com.claims.service.ClaimService;

@Controller
public class EditClaimController {
	@Autowired(required = true)
	@Qualifier(value = "claimService")
	private ClaimService claimService;

	public void setClaimService(ClaimService claimService) {
		this.claimService = claimService;
	}

	@RequestMapping("/AdmLogged1")
	public String list(ModelMap model) {
		return "AdmLogged";
	}

	@RequestMapping("/AdmNewClaims")
	public String listClaim(ModelMap model) {
		// calims.put("AdmNewClaims", new Claim());
		List<Claim> claims;
		try {
			claims = claimService.listClaim();
			model.addAttribute("claimList", claims);
		} catch (Exception ex) {
			model.addAttribute("message", ex.getMessage());
			model.addAttribute("error", true);
		}
		return "AdmNewClaims";
	}

	@RequestMapping("/Processed")
	public String listClaimP(ModelMap model) {
		// calims.put("AdmNewClaims", new Claim());
		List<Claim> claims;
		try {
			claims = claimService.listClaimP();
			model.addAttribute("claimList", claims);
		} catch (Exception ex) {
			model.addAttribute("message", ex.getMessage());
			model.addAttribute("error", true);
		}
		return "Processed";
	}
	/*
	 * @RequestMapping(value = "/AdmLogged2", method = RequestMethod.GET) public
	 * String updateClaim(@ModelAttribute("claim") planCode claim) {
	 * System.out.println(claim.getPlanCode()); claimService.updateClaim(claim);
	 * return "redirect:/AdmLogged1"; }
	 */

	@RequestMapping("AdmLogged2/{memid}")
	public String updateClaim(ModelMap model, @PathVariable("memid") Integer memid) {

		claimService.updateClaim(memid);

		return "redirect:/AdmLogged1";
	}

	@RequestMapping("AdmLogged3/{memid}")
	public String update1(ModelMap model, @PathVariable("memid") Integer memid) {

		claimService.updateClaim1(memid);

		return "redirect:/AdmLogged1";
	}

	@RequestMapping(value = "/NewPage/{memid}")
	public String list1(ModelMap model, @PathVariable("memid") String memid) {
		{
			System.out.println("here");
			List<Member> members;
			try {
				System.out.println(memid);
				members = claimService.listMember(memid);
				System.out.println(members);
				model.addAttribute("memberList", members);
			} catch (Exception ex) {
				model.addAttribute("message", ex.getMessage());
				model.addAttribute("error", true);
			}
			return "NewPage";
		}
	}

	@RequestMapping(value = "/NewPage1/{memid}")
	public String list2(ModelMap model, @PathVariable("memid") Integer memid) {
		{
			// calims.put("AdmNewClaims", new Claim());
			System.out.println("here");
			List<Claim> claims;
			try {
				System.out.println(memid);
				claims = claimService.listClaim1(memid);
				System.out.println(claims);
				model.addAttribute("claimList", claims);
			} catch (Exception ex) {
				model.addAttribute("message", ex.getMessage());
				model.addAttribute("error", true);
			}
			return "NewPage1";
		}
	}

	@RequestMapping("/NewLogin")
	public String listMember1(ModelMap model) {
		// calims.put("AdmNewClaims", new Claim());
		List<Member> member;
		try {
			member = claimService.listMember1();
			model.addAttribute("memberList", member);
		} catch (Exception ex) {
			model.addAttribute("message", ex.getMessage());
			model.addAttribute("error", true);
		}
		return "NewLogin";
	}

	@RequestMapping("/NewLogin1/{memid}")
	public String update3(ModelMap model, @PathVariable("memid") String memid) {
		claimService.updateClaim3(memid);
		return "redirect:/NewLogin";
	}

	@RequestMapping("/NewLogin2/{memid}")
	public String update4(ModelMap model, @PathVariable("memid") String memid) {
		claimService.updateClaim4(memid);
		return "redirect:/NewLogin";
	}

	@RequestMapping("/Processed1/{claimId}")
	public String listClaimP1(@PathVariable("claimId") String claimId, ModelMap model) {
		// calims.put("AdmNewClaims", new Claim());
		model.addAttribute("claim", new Claim());
		model.addAttribute("claimId", claimId);
		return "Processed1";
	}

	@RequestMapping(value = "/Processed2")
	public String updateAmount(@ModelAttribute(value = "claim") Claim claim) {
		claimService.updateA(claim);
		return "redirect:/Processed";
	}

	@RequestMapping("/AdmProcessedClaims")
	public String listClaim(Map<String, Object> m) {
		m.put("claim", new planCode());
		m.put("claimList", claimService.listplanCode());
		m.put("planCode", null);
		return "AdmProcessedClaims";
	}

	@RequestMapping(value = "/claim/add", method = RequestMethod.POST)
	public String addClaim(@ModelAttribute("claim") planCode claim) {
		claimService.addClaim(claim);
		return "redirect:/AdmProcessedClaims";
	}

	@RequestMapping("/edit/{cid}") // {} this used to change the id accordingly
									// like 100,200..so on
	public String editClaim(@PathVariable("cid") String planCode, Map<String, Object> m, ModelMap modelMap) {
		System.out.println(planCode);
		planCode c = claimService.getClaimById1(planCode);
		System.out.println("PLAN CODE " + c.getPlanCode());
		m.put("claim", c);
		// represents one customer object
		modelMap.addAttribute("planCode", planCode);
		System.out.println("plan code " + planCode);
		m.put("claimList", claimService.listplanCode());
		return "edit";
	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public String updateClaim5(@ModelAttribute("claim") planCode claim) {
		System.out.println(claim.getPlanCode());
		claimService.updateClaim5(claim);
		return "redirect:/AdmProcessedClaims";
	}

	@RequestMapping("/delete/{cid}")
	public String deleteClaim(@PathVariable("cid") String planCode) {
		claimService.removeClaim(planCode);
		return "redirect:/AdmProcessedClaims";
	}

}