package com.claims.controller;

import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.claims.entity.Admin;
import com.claims.entity.Claim;
import com.claims.entity.Member;
import com.claims.entity.planCode;
import com.claims.service.AdminService;
import com.claims.service.IdService;

@Controller
public class AdminController {
	private AdminService adminService;

	@Autowired(required = true)
	@Qualifier(value = "adminService")
	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	@RequestMapping("/Welcome")
	public String listWelcome() {
		return "Welcome";
	}

	@RequestMapping(value = "/login/admin", method = RequestMethod.GET)
	public String loginAdminPage(ModelMap model) {
		System.out.println("Inside Admin Login Page");
		model.addAttribute("admin", new Admin());
		model.addAttribute("check", -1);
		return "AdmLogin";
	}

	@RequestMapping(value = "/login/member", method = RequestMethod.GET)
	public String loginMemberPage(ModelMap model) {
		System.out.println("Inside Member Login Page");
		model.addAttribute("member", new Member());
		model.addAttribute("check", -1);
		return "MemLogin";
	}

	@RequestMapping(value = "/login/admin", method = RequestMethod.POST)
	public String loginAdmin(@ModelAttribute(value = "admin") Admin admin, ModelMap model, HttpSession session) {
		System.out.println(admin.getAdminId() + admin.getPassword());
		Admin u = adminService.fetchAdminByAdminId(admin.getAdminId());
		System.out.println(u);
		int check = 0;
		if (u != null) {
			check = 1;
			u.setPassword(admin.getPassword());
			if (adminService.checkPassword(u)) {
				check = 2;
			}
		}
		if (check == 2) {
			session.setAttribute("userSession", u);
			System.out.println("Redirecting to admin");
			return "AdmLogged";
		}
		model.addAttribute("check", check);
		return "AdmLogin";
	}

	@RequestMapping(value = "/login/member", method = RequestMethod.POST)
	public String loginMember(@ModelAttribute(value = "member") Member member, ModelMap model, HttpSession session) {
		System.out.println(member.getMemberId() + member.getPassword());
		Member u = adminService.fetchMemberByMemberId(member.getMemberId());
		// System.out.println(u.getStatus() + " status ");
		int check = 0;

		if (u != null) {
			check = 1;
			u.setPassword(member.getPassword());
			if (adminService.checkPassword1(u)) {
				check = 3;
			}
			if (u.getStatus().equalsIgnoreCase("New") || u.getStatus().equalsIgnoreCase("denied")) {
				System.out.println("new login or denied login");
				model.addAttribute("check", 2);
			}
		}
		
		if (check == 3) {
			session.setAttribute("userSession", u);
			System.out.println("Redirecting to member");
			return "ClaimButtons";
		}
		model.addAttribute("check", check);
		return "MemLogin";
	}

	@RequestMapping("/register/admin")
	public String listAdmin(ModelMap map) {
		map.addAttribute("admin", new Admin());
		map.addAttribute("adminList", adminService.listAdmin());
		return "AdmReg";
	}

	@RequestMapping("/register/member")
	public String listMember(ModelMap map) {
		map.addAttribute("member", new Member());
		map.addAttribute("memberList", adminService.listMember());
		List<String> l = adminService.fetchPlanCodes();
		map.addAttribute("planCode", l);
		return "MemReg";
	}

	@RequestMapping(value = "/register/admin", method = RequestMethod.POST)
	public String addAdmin(@ModelAttribute("admin") Admin admin, ModelMap map) {
		System.out.println("Inside Add Method");
		System.out.println("here0");
		String id = IdService.getAlphaNumericString(5);
		admin.setAdminId(id);
		try {
			adminService.addAdmin(admin);
			System.err.println(id + " ID String");
			map.addAttribute("id", id);
			map.addAttribute("error", 0);
		} catch (Exception ex) {
			ex.printStackTrace();
			map.addAttribute("error", 1);
			map.addAttribute("message", ex.getMessage());
		}
		return "AdmReg";
	}

	@RequestMapping(value = "/register/member", method = RequestMethod.POST)
	public String addMember(@ModelAttribute("member") Member member, ModelMap map) {
		System.out.println("Inside Add Method");
		System.out.println("here0");
		String id = IdService.getAlphaNumericString(5);
		member.setMemberId(id);

		try {
			adminService.addMember(member);
			map.addAttribute("id", id);
			map.addAttribute("error", 0);

		} catch (Exception ex) {
			ex.printStackTrace();
			map.addAttribute("error", 1);
			map.addAttribute("message", ex.getMessage());
		}
		System.err.println(id + " ID String");
		return "MemReg";
	}

	@RequestMapping(value = "/resPas", method = RequestMethod.GET)
	public String userForgotPasswordCall(ModelMap model) {
		model.addAttribute("resetPass", new Admin());
		return "resPas";
	}

	@RequestMapping(value = "/resPas1", method = RequestMethod.GET)
	public String userForgotPasswordCall1(ModelMap model) {
		model.addAttribute("resetPass1", new Member());
		return "resPas1";
	}

	@RequestMapping(value = "/forgotpassword", method = RequestMethod.POST)
	public String verifyForgotPassword(@ModelAttribute("pass") Admin user, Model model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside forgotpassword Verification Controller");
		Admin dbUser = adminService.findById(user.getEmailId());
		int loginStatus = 0;
		String a = "";
		String b = "";
		String url = null;
		if (dbUser != null) {
			if (dbUser.getEmailId() != null) {

				loginStatus = 1; // HINT ANSWER MATCHED
			} else {
				loginStatus = -2; // HINT ANSWER mismatch
			}
		}
		if (loginStatus == 1) {
			a = dbUser.getPassword();
			b = dbUser.getEmailId();
			url = "password";
		} else {
			url = "resPas";
		}
		model.addAttribute("a", a);
		model.addAttribute("b", b);
		System.err.println("LoginStatus= " + loginStatus);
		model.addAttribute("loginStatus", loginStatus);
		model.addAttribute("resetPass", new Admin());
		// request.getSession().setAttribute("loginStatus", loginStatus);
		return url;
	}

	@RequestMapping(value = "/changepassword", method = RequestMethod.POST)
	public String newPassword(@ModelAttribute("admin") Admin user, Model model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside forgotpassword Verification Controller");
		System.out.println("_--------------------------" + user);
		Admin dbUser = adminService.findById(user.getEmailId());
		System.out.println(dbUser + "-----------------------------------------------------------------");
		// String a="";
		String url = "AdmLogin";
		dbUser.setPassword(user.getPassword()); // PASSWORD CHANGING
		adminService.updatePassword(dbUser);
		System.out.println("_----------========----------------" + dbUser);
		int loginStatus = 1;
		return url;
	}

	@RequestMapping(value = "/forgotpassword1", method = RequestMethod.POST)
	public String verifyForgotPassword1(@ModelAttribute("pass1") Member user, Model model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside forgotpassword Verification Controller");
		Member dbUser = adminService.findById1(user.getEmailId());
		int loginStatus = 0;
		String a = "";
		String b = "";
		String url = null;
		if (dbUser != null) {
			if (dbUser.getEmailId() != null) {

				loginStatus = 1; // HINT ANSWER MATCHED
			} else {
				loginStatus = -2; // HINT ANSWER mismatch
			}
		}
		if (loginStatus == 1) {
			a = dbUser.getPassword();
			b = dbUser.getEmailId();
			url = "password1";
		} else {
			url = "resPas1";
		}
		model.addAttribute("a", a);
		model.addAttribute("b", b);
		System.err.println("LoginStatus= " + loginStatus);
		model.addAttribute("loginStatus", loginStatus);
		model.addAttribute("resetPass1", new Member());
		// request.getSession().setAttribute("loginStatus", loginStatus);
		return url;
	}

	@RequestMapping(value = "/changepassword1", method = RequestMethod.POST)
	public String newPassword1(@ModelAttribute("member") Member user, Model model, HttpServletRequest request,
			HttpServletResponse response) {
		System.err.println("Inside forgotpassword Verification Controller");
		System.out.println("_--------------------------" + user);
		Member dbUser = adminService.findById1(user.getEmailId());
		System.out.println(dbUser + "-----------------------------------------------------------------");
		// String a="";
		String url = "MemLogin";
		dbUser.setPassword(user.getPassword()); // PASSWORD CHANGING
		adminService.updatePassword1(dbUser);
		System.out.println("_----------========----------------" + dbUser);
		int loginStatus = 1;
		return url;
	}

	@RequestMapping("/ClaimForm3")
	public String list(ModelMap model) {
		return "ClaimButtons";
	} 
	
	@RequestMapping("/ClaimForm")
	public String listClaim(ModelMap m) {
		try {
			m.addAttribute("claim", new Claim());
			m.addAttribute("claimList", adminService.listClaim2());
		} 
		catch (Exception ex) {
			ex.printStackTrace();
			m.addAttribute("error", 1);
			m.addAttribute("message", ex.getMessage());
		}
		return "ClaimForm";
	}

	@RequestMapping(value = "/ClaimForm2", method = RequestMethod.POST)
	public String addClaim(@ModelAttribute("claim") Claim claim) {
		if (null == claim.getClaimId()) {
			Random r = new Random();
			int num = r.nextInt(90000) + 10000;
			claim.setClaimId(num);
			adminService.addClaim2(claim);

		} else {
			adminService.updateClaim2(claim);
		}
		return "ClaimButtons";
	}

	@RequestMapping("/edit1/{cid}") // {} this used to change the id accordingly
	// like 100,200..so on
	public String editCustomer(@PathVariable("cid") Integer custid, Map<String, Object> m) {
		Claim c = adminService.getClaimById2(custid);
		m.put("claim", c); // represents one customer object
		m.put("claimlist", adminService.listClaim2());
		return "ClaimList";
	}

	@RequestMapping(value = "/claim/list")
	public String list2(ModelMap model, HttpSession session) {
		// calims.put("AdmNewClaims", new Claim());
		System.out.println("here123");
		List<Claim> claims;
		try {
			Member m = (Member) session.getAttribute("userSession");
			claims = adminService.listClaim2(m.getMemberId());
			System.out.println(claims + "123");
			model.addAttribute("claimList", claims);
		} catch (Exception ex) {
			ex.printStackTrace();
			model.addAttribute("message", ex.getMessage());
			model.addAttribute("error", true);
		}
		return "NewPage2";
	}
	
	@RequestMapping(value="/logout")
	public String logout(HttpSession session)
	{
		session.invalidate();
		return "redirect:/Welcome";
	}
}