package com.claims.service;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.claims.dao.ClaimDao;
import com.claims.entity.Claim;
import com.claims.entity.planCode;
import com.claims.entity.Member;
@Service
public class ClaimServiceImpl implements ClaimService {

	@Autowired
	private ClaimDao claimDao;
	
	public void setClaimDao(ClaimDao claimDao) {
	this.claimDao = claimDao;
}
	
	@Override
	public List<Claim> listClaim() {
		List<Claim> l=claimDao.listClaim();
		System.err.println("Claims count " + l.size());
		return l;
	}
	@Override
	public List<Member> listMember1() {
		List<Member> l=claimDao.listMember1();
		System.err.println("Claims count " + l.size());
		return l;
	}
	@Override
	public List<Claim> listClaimP() {
		List<Claim> l=claimDao.listClaimP();
		System.err.println("Claims count " + l.size());
		return l;
	}
	@Override
	public void updateClaim(Integer c) {
		claimDao.updateClaim(c);

	}
	@Override
	public void updateClaim1(Integer c) {
		claimDao.updateClaim1(c);

	}
	@Override
	public void updateClaim3(String c) {
		claimDao.updateClaim3(c);

	}
	@Override
	public void updateClaim4(String c) {
		claimDao.updateClaim4(c);

	}
	@Override
	public Claim getClaimById(Integer ClaimId) {
		
		return claimDao.getClaimById(ClaimId);
	}
	@Override
	public List<Member> listMember(String memid) {
		List<Member> l=claimDao.listMember(memid);
		System.err.println("Claims count " + l.size());
		return l;
	}
	@Override
	public List<Claim> listClaim1(Integer memid) {
		List<Claim> l=claimDao.listClaim1(memid);
		System.err.println("Claims count " + l.size());
		return l;
	}

	@Override
	public boolean updateA(Claim claim) {
		return claimDao.updateA(claim);
		
	}

	@Override
	public List<planCode> listplanCode() {
		List<planCode> l = claimDao.listplanCode();
		return l;
	}

	@Override
	public void addClaim(planCode c) {
		// TODO Auto-generated method stub
		claimDao.addClaim(c);
	}

	@Override
	public void updateClaim5(planCode c) {
		// TODO Auto-generated method stub
		claimDao.updateClaim5(c);
	}

	@Override
	public void removeClaim(String planCode) {
		// TODO Auto-generated method stub
		claimDao.removeClaim(planCode);
	}

	@Override

	public planCode getClaimById1(String planCode) {
		// TODO Auto-generated method stub
		return claimDao.getClaimById1(planCode);

	}
}
