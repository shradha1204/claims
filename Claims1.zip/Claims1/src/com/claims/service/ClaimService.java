package com.claims.service;
import java.util.List;
import com.claims.entity.Claim;
import com.claims.entity.planCode;
import com.claims.entity.Member;
public interface ClaimService {
	public List<Claim> listClaim();
	public void updateClaim(Integer c);
	public void updateClaim1(Integer memid);
	public void updateClaim3(String memid);
	public void updateClaim4(String memid);
	public Claim getClaimById(Integer ClaimId);
	public List<Member> listMember(String memeid);
	public List<Claim> listClaim1(Integer memid);
	public List<Claim> listClaimP();
	public List<Member> listMember1();
	public boolean updateA(Claim claim);
	public void addClaim(planCode c);
	public void updateClaim5(planCode c);
	public planCode getClaimById1(String planCode);
	public List<planCode> listplanCode();
	public void removeClaim(String planCode);
}
