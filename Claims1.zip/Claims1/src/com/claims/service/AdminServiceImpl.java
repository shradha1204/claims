package com.claims.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import com.claims.dao.AdminDao;
import com.claims.entity.Admin;
import com.claims.entity.Claim;
import com.claims.entity.Member;
import com.claims.entity.planCode;
public class AdminServiceImpl implements AdminService {
	
	
	@Autowired
	private AdminDao adminDao;
	public void setAdminDao(AdminDao adminDao) {
		this.adminDao = adminDao;
	}
	@Override
	public void addAdmin(Admin a) {
		adminDao.addAdmin(a);

	}
	@Override
	public void addMember(Member m) {
		adminDao.addMember(m);

	}

	@Override
	public List<Admin> listAdmin() {
		List<Admin> l = adminDao.listAdmin();
		return l;
	}

	@Override
	public List<Member> listMember() {
		List<Member> l = adminDao.listMember();
		return l;
	}

	@Override
	public Admin fetchAdminByAdminId(String id) {
		return adminDao.fetchAdminByAdminId(id);
	}

	@Override
	public boolean checkPassword(Admin user) {
		// TODO Auto-generated method stub
		return adminDao.checkPassword(user);
	}

	@Override
	public Member fetchMemberByMemberId(String id) {
		return adminDao.fetchMemberByMemberId(id);
	}
	@Override
	public boolean checkPassword1(Member user) {
		return adminDao.checkPassword1(user);
	}
	@Override
	public Admin findById(String emailId) {

		return adminDao.findById(emailId);
	}
	@Override
	public void updatePassword(Admin dbUser) {
		System.out.println("In service- ---------------------------------------");
		adminDao.updatePassword(dbUser);
	}
	@Override
	public Member findById1(String emailId) {

		return adminDao.findById1(emailId);
	}
	@Override
	public void updatePassword1(Member dbUser) {
		System.out.println("In service- ---------------------------------------");
		adminDao.updatePassword1(dbUser);
	}
	
	@Override
	public List<String> fetchPlanCodes() {
		// TODO Auto-generated method stub
		return adminDao.fetchPlanCodes();
	}
	@Override
	public void addClaim2(Claim c) {
		// TODO Auto-generated method stub
		adminDao.addClaim2(c);
	}

	@Override
	public void updateClaim2(Claim c) {
		// TODO Auto-generated method stub
		adminDao.updateClaim2(c);

	}

	@Override
	public Claim getClaimById2(Integer Claimid) {
		// TODO Auto-generated method stub
		return adminDao.getClaimById2(Claimid);
	}

	@Override
	public List<Claim> listClaim2() {
		// TODO Auto-generated method stub
		List<Claim> l = adminDao.listClaim2();
		return l;
	}

	@Override
	public List<Claim> listClaim2(String memid) {
		List<Claim> l = adminDao.listClaim2(memid);
		System.err.println("Claims count " + l.size());
		return l;
	}
	
}
