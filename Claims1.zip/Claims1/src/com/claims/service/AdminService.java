package com.claims.service;

import java.util.List;

import com.claims.entity.Admin;
import com.claims.entity.Member;
import com.claims.entity.planCode;
import com.claims.entity.Claim;

public interface AdminService {
	public void addAdmin(Admin a);
	public void addMember(Member m);
	public List<Admin> listAdmin();
	public List<Member> listMember();
	public Admin fetchAdminByAdminId(String id);
	boolean checkPassword(Admin user);
	public Member fetchMemberByMemberId(String id);
	boolean checkPassword1(Member user);
	public Admin findById(String emailId);
	public void updatePassword(Admin dbUser);
	public Member findById1(String emailId);
	public void updatePassword1(Member dbUser);
	public void addClaim2(Claim c);
	public void updateClaim2(Claim c);
	//public planCode getPlanCodeById(String planCode);
	public List<String> fetchPlanCodes();
	public Claim getClaimById2(Integer Claimid);
	public List<Claim> listClaim2();
	public List<Claim> listClaim2(String memid);
}
